# Horrorween Application Requirements Document\n
## 1. Application Overview
### 1.1 Application Name
Horrorween

### 1.2 Application Description
A Halloween-themed educational and entertainment web application designed for children, combining horror elements with fun learning experiences. The app features story content, math exercises, gaming, and a reward system.

## 2. Application Features
### 2.1 Home Page
- Display a collection of different Halloween kids stories
- Stories should be organized and easily accessible for children
- Include story thumbnails and titles
- Stories should be age-appropriate with Halloween themes
\n### 2.2 Maths Page
- Provide math questions for beginners
- Four types of operations:
  + Addition (Sum)
  + Subtraction (Difference)
  + Multiplication
  + Division
- Questions should be age-appropriate for children learning basic math
- Track correct answers for points calculation\n
### 2.3 Game Page
- Snake game with three difficulty levels:
  + Easy
  + Medium
  + Hard
- Classic snake gameplay mechanics
- Level selection interface

### 2.4 Points Page
- Display points earned from solving math questions
- Points are represented as chocolates\n- Visual representation of chocolate rewards based on performance
- Show total accumulated points/chocolates

## 3. Design Style
### 3.1 Theme\nHalloween-themed with a balance of horror and child-friendly enjoyment

### 3.2 Visual Design
- Color Scheme: Orange and purple as primary colors with black accents, creating a festive Halloween atmosphere while remaining playful
- Background: Dark mode with horror elements including shadowy forests, glowing eyes in darkness, misty graveyards, and silhouettes of haunted houses; designed to be spooky yet child-appropriate
- Dynamic Background: Background changes automatically every 30 minutes to maintain visual interest
- Layout: Card-based layout with clear navigation between four main pages
- Icons: Halloween-themed icons (pumpkins, candy, ghosts) with rounded edges for a friendly appearance
- Typography: Bold, readable fonts suitable for children with slight spooky styling