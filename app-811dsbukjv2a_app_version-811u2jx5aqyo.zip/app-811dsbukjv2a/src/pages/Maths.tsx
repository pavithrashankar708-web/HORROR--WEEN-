import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { Calculator, Check, X, Trophy, Sparkles } from 'lucide-react';
import { Progress } from '@/components/ui/progress';

type OperationType = 'addition' | 'subtraction' | 'multiplication' | 'division';

interface Question {
  num1: number;
  num2: number;
  operation: OperationType;
  answer: number;
}

const operationSymbols = {
  addition: '+',
  subtraction: '-',
  multiplication: '×',
  division: '÷'
};

const operationNames = {
  addition: 'Addition (Sum)',
  subtraction: 'Subtraction (Difference)',
  multiplication: 'Multiplication',
  division: 'Division'
};

const Maths: React.FC = () => {
  const [selectedOperation, setSelectedOperation] = useState<OperationType | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [userAnswer, setUserAnswer] = useState('');
  const [score, setScore] = useState(0);
  const [questionsAnswered, setQuestionsAnswered] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const { toast } = useToast();

  const generateQuestion = (operation: OperationType): Question => {
    let num1: number, num2: number, answer: number;

    switch (operation) {
      case 'addition':
        num1 = Math.floor(Math.random() * 50) + 1;
        num2 = Math.floor(Math.random() * 50) + 1;
        answer = num1 + num2;
        break;
      case 'subtraction':
        num1 = Math.floor(Math.random() * 50) + 20;
        num2 = Math.floor(Math.random() * num1) + 1;
        answer = num1 - num2;
        break;
      case 'multiplication':
        num1 = Math.floor(Math.random() * 12) + 1;
        num2 = Math.floor(Math.random() * 12) + 1;
        answer = num1 * num2;
        break;
      case 'division':
        num2 = Math.floor(Math.random() * 10) + 2;
        answer = Math.floor(Math.random() * 10) + 1;
        num1 = num2 * answer;
        break;
      default:
        num1 = 0;
        num2 = 0;
        answer = 0;
    }

    return { num1, num2, operation, answer };
  };

  const startPractice = (operation: OperationType) => {
    setSelectedOperation(operation);
    setCurrentQuestion(generateQuestion(operation));
    setScore(0);
    setQuestionsAnswered(0);
    setUserAnswer('');
    setShowResult(false);
  };

  const checkAnswer = () => {
    if (!currentQuestion || userAnswer.trim() === '') {
      toast({
        title: 'Oops! 👻',
        description: 'Please enter an answer first!',
        variant: 'destructive'
      });
      return;
    }

    const numAnswer = Number.parseFloat(userAnswer);
    if (Number.isNaN(numAnswer)) {
      toast({
        title: 'Invalid Input! 🎃',
        description: 'Please enter a valid number!',
        variant: 'destructive'
      });
      return;
    }

    const correct = Math.abs(numAnswer - currentQuestion.answer) < 0.01;
    setIsCorrect(correct);
    setShowResult(true);

    if (correct) {
      const newScore = score + 1;
      setScore(newScore);
      
      const currentPoints = Number.parseInt(localStorage.getItem('horrorweenPoints') || '0');
      localStorage.setItem('horrorweenPoints', String(currentPoints + 1));

      toast({
        title: '🎉 Correct!',
        description: 'You earned 1 chocolate! Keep going!',
      });
    } else {
      toast({
        title: '❌ Not quite right',
        description: `The correct answer is ${currentQuestion.answer}. Try the next one!`,
        variant: 'destructive'
      });
    }

    setQuestionsAnswered(questionsAnswered + 1);
  };

  const nextQuestion = () => {
    if (selectedOperation) {
      setCurrentQuestion(generateQuestion(selectedOperation));
      setUserAnswer('');
      setShowResult(false);
    }
  };

  const backToMenu = () => {
    setSelectedOperation(null);
    setCurrentQuestion(null);
    setUserAnswer('');
    setShowResult(false);
  };

  if (!selectedOperation) {
    return (
      <div className="min-h-screen halloween-bg-2 py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Calculator className="h-12 w-12 text-primary" />
              <h1 className="text-5xl xl:text-6xl font-bold gradient-text">
                Math Practice
              </h1>
            </div>
            <p className="text-xl text-muted-foreground">
              Choose an operation to start practicing! 🧮
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {(Object.keys(operationNames) as OperationType[]).map((operation) => (
              <Card
                key={operation}
                className="halloween-shadow smooth-transition hover:scale-105 cursor-pointer bg-card/95 backdrop-blur-sm"
                onClick={() => startPractice(operation)}
              >
                <CardHeader>
                  <CardTitle className="text-3xl text-center">
                    {operationSymbols[operation]}
                  </CardTitle>
                  <CardDescription className="text-center text-lg">
                    {operationNames[operation]}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full" size="lg">
                    Start Practice
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen halloween-bg-3 py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <Card className="halloween-shadow bg-card/95 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-3xl">
                {operationNames[selectedOperation]}
              </CardTitle>
              <Button variant="outline" onClick={backToMenu}>
                Back to Menu
              </Button>
            </div>
            <CardDescription className="text-lg mt-2">
              Score: {score} / {questionsAnswered}
            </CardDescription>
            {questionsAnswered > 0 && (
              <Progress value={(score / questionsAnswered) * 100} className="mt-2" />
            )}
          </CardHeader>
          <CardContent className="space-y-6">
            {currentQuestion && (
              <>
                <div className="bg-muted rounded-lg p-8 text-center">
                  <div className="text-5xl font-bold mb-4">
                    {currentQuestion.num1} {operationSymbols[currentQuestion.operation]} {currentQuestion.num2} = ?
                  </div>
                  {showResult && (
                    <div className={`flex items-center justify-center gap-2 text-2xl font-semibold ${isCorrect ? 'text-primary' : 'text-destructive'}`}>
                      {isCorrect ? (
                        <>
                          <Check className="h-8 w-8" />
                          <span>Correct! 🎉</span>
                        </>
                      ) : (
                        <>
                          <X className="h-8 w-8" />
                          <span>Answer: {currentQuestion.answer}</span>
                        </>
                      )}
                    </div>
                  )}
                </div>

                {!showResult ? (
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="answer" className="text-lg">Your Answer:</Label>
                      <Input
                        id="answer"
                        type="number"
                        value={userAnswer}
                        onChange={(e) => setUserAnswer(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && checkAnswer()}
                        placeholder="Enter your answer"
                        className="text-2xl text-center mt-2"
                        autoFocus
                      />
                    </div>
                    <Button onClick={checkAnswer} className="w-full" size="lg">
                      <Check className="mr-2 h-5 w-5" />
                      Check Answer
                    </Button>
                  </div>
                ) : (
                  <Button onClick={nextQuestion} className="w-full" size="lg">
                    <Sparkles className="mr-2 h-5 w-5" />
                    Next Question
                  </Button>
                )}

                {questionsAnswered >= 5 && (
                  <Card className="bg-primary/10 border-primary">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-3">
                        <Trophy className="h-6 w-6 text-primary" />
                        <p className="font-medium">
                          Great job! You've earned {score} chocolate{score !== 1 ? 's' : ''}! 🍫
                        </p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Maths;
