import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trophy, Candy, Star, Sparkles, RotateCcw } from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const Points: React.FC = () => {
  const [points, setPoints] = useState(0);

  useEffect(() => {
    const savedPoints = localStorage.getItem('horrorweenPoints');
    setPoints(savedPoints ? Number.parseInt(savedPoints) : 0);
  }, []);

  const resetPoints = () => {
    localStorage.setItem('horrorweenPoints', '0');
    setPoints(0);
  };

  const getLevel = (pts: number): { level: number; name: string; nextLevel: number } => {
    if (pts < 10) return { level: 1, name: 'Beginner Ghost', nextLevel: 10 };
    if (pts < 25) return { level: 2, name: 'Spooky Skeleton', nextLevel: 25 };
    if (pts < 50) return { level: 3, name: 'Wicked Witch', nextLevel: 50 };
    if (pts < 100) return { level: 4, name: 'Vampire Master', nextLevel: 100 };
    return { level: 5, name: 'Halloween Legend', nextLevel: 100 };
  };

  const level = getLevel(points);
  const progressToNext = level.level < 5 
    ? ((points % level.nextLevel) / level.nextLevel) * 100 
    : 100;

  const chocolateRows = Math.ceil(points / 10);
  const chocolates = Array.from({ length: points }, (_, i) => i);

  return (
    <div className="min-h-screen halloween-bg-2 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Trophy className="h-12 w-12 text-primary animate-bounce" />
            <h1 className="text-5xl xl:text-6xl font-bold gradient-text">
              Your Rewards
            </h1>
            <Star className="h-12 w-12 text-secondary animate-bounce" />
          </div>
          <p className="text-xl text-muted-foreground">
            Collect chocolates by solving math problems! 🍫
          </p>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 mb-8">
          <Card className="halloween-shadow bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-3xl flex items-center gap-2">
                <Candy className="h-8 w-8 text-primary" />
                Total Chocolates
              </CardTitle>
              <CardDescription className="text-lg">
                Earned from math practice
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-6xl font-bold text-center gradient-text mb-4">
                {points}
              </div>
              <div className="flex justify-center gap-2">
                {[...Array(Math.min(5, points))].map((_, i) => (
                  <Candy key={`preview-${i}`} className="h-8 w-8 text-primary" />
                ))}
                {points > 5 && <span className="text-2xl">...</span>}
              </div>
            </CardContent>
          </Card>

          <Card className="halloween-shadow bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-3xl flex items-center gap-2">
                <Sparkles className="h-8 w-8 text-secondary" />
                Your Level
              </CardTitle>
              <CardDescription className="text-lg">
                Keep earning to level up!
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-4xl font-bold mb-2">Level {level.level}</div>
                <div className="text-2xl text-primary font-semibold">{level.name}</div>
              </div>
              {level.level < 5 && (
                <div className="space-y-2">
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Progress to next level</span>
                    <span>{points} / {level.nextLevel}</span>
                  </div>
                  <Progress value={progressToNext} className="h-3" />
                </div>
              )}
              {level.level === 5 && (
                <div className="text-center text-lg font-semibold text-primary">
                  🎉 Maximum Level Reached! 🎉
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <Card className="halloween-shadow mb-8 bg-card/95 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-3xl">Chocolate Collection</CardTitle>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline">
                    <RotateCcw className="mr-2 h-4 w-4" />
                    Reset Points
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                    <AlertDialogDescription>
                      This will reset all your earned chocolates and progress. This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={resetPoints}>Reset</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
            <CardDescription className="text-lg">
              All the chocolates you've earned so far
            </CardDescription>
          </CardHeader>
          <CardContent>
            {points === 0 ? (
              <div className="text-center py-12">
                <Candy className="h-24 w-24 text-muted mx-auto mb-4 opacity-50" />
                <p className="text-xl text-muted-foreground mb-4">
                  No chocolates yet! Start solving math problems to earn rewards.
                </p>
                <Button asChild>
                  <a href="/maths">Go to Maths Page</a>
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-5 sm:grid-cols-8 md:grid-cols-10 xl:grid-cols-15 gap-4 p-4 bg-muted rounded-lg">
                {chocolates.map((i) => (
                  <div
                    key={`chocolate-${i}`}
                    className="flex items-center justify-center animate-in fade-in zoom-in"
                    style={{ animationDelay: `${(i % 50) * 20}ms` }}
                  >
                    <Candy className="h-8 w-8 text-primary smooth-transition hover:scale-125" />
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="halloween-shadow bg-card/95 backdrop-blur-sm">
          <CardContent className="p-6">
            <div className="text-center space-y-4">
              <h3 className="text-2xl font-bold">Level Milestones</h3>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mt-4">
                {[
                  { level: 1, name: 'Beginner Ghost', points: '0-9', emoji: '👻' },
                  { level: 2, name: 'Spooky Skeleton', points: '10-24', emoji: '💀' },
                  { level: 3, name: 'Wicked Witch', points: '25-49', emoji: '🧙' },
                  { level: 4, name: 'Vampire Master', points: '50-99', emoji: '🧛' },
                  { level: 5, name: 'Halloween Legend', points: '100+', emoji: '🎃' }
                ].map((milestone) => (
                  <div
                    key={milestone.level}
                    className={`p-4 rounded-lg border-2 ${
                      level.level === milestone.level
                        ? 'border-primary bg-primary/10'
                        : 'border-border bg-card'
                    }`}
                  >
                    <div className="text-4xl mb-2">{milestone.emoji}</div>
                    <div className="font-semibold">{milestone.name}</div>
                    <div className="text-sm text-muted-foreground">{milestone.points} pts</div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Points;
