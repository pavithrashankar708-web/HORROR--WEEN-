import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Gamepad2, Play, Pause, RotateCcw, Trophy } from 'lucide-react';

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';
type Difficulty = 'easy' | 'medium' | 'hard';

interface Position {
  x: number;
  y: number;
}

const GRID_SIZE = 20;
const CELL_SIZE = 20;

const difficultySettings = {
  easy: { speed: 150, name: 'Easy', color: 'bg-primary' },
  medium: { speed: 100, name: 'Medium', color: 'bg-secondary' },
  hard: { speed: 60, name: 'Hard', color: 'bg-destructive' }
};

const Game: React.FC = () => {
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [snake, setSnake] = useState<Position[]>([{ x: 10, y: 10 }]);
  const [food, setFood] = useState<Position>({ x: 15, y: 15 });
  const [direction, setDirection] = useState<Direction>('RIGHT');
  const [nextDirection, setNextDirection] = useState<Direction>('RIGHT');
  const [isPlaying, setIsPlaying] = useState(false);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const { toast } = useToast();
  const gameLoopRef = useRef<NodeJS.Timeout | null>(null);

  const generateFood = useCallback((snakeBody: Position[]): Position => {
    let newFood: Position;
    do {
      newFood = {
        x: Math.floor(Math.random() * GRID_SIZE),
        y: Math.floor(Math.random() * GRID_SIZE)
      };
    } while (snakeBody.some(segment => segment.x === newFood.x && segment.y === newFood.y));
    return newFood;
  }, []);

  const resetGame = useCallback(() => {
    const initialSnake = [{ x: 10, y: 10 }];
    setSnake(initialSnake);
    setFood(generateFood(initialSnake));
    setDirection('RIGHT');
    setNextDirection('RIGHT');
    setScore(0);
    setGameOver(false);
    setIsPlaying(false);
  }, [generateFood]);

  const startGame = (selectedDifficulty: Difficulty) => {
    setDifficulty(selectedDifficulty);
    resetGame();
    setIsPlaying(true);
  };

  const togglePause = () => {
    if (!gameOver) {
      setIsPlaying(!isPlaying);
    }
  };

  const moveSnake = useCallback(() => {
    if (!isPlaying || gameOver) return;

    setDirection(nextDirection);

    setSnake(prevSnake => {
      const head = prevSnake[0];
      let newHead: Position;

      switch (nextDirection) {
        case 'UP':
          newHead = { x: head.x, y: head.y - 1 };
          break;
        case 'DOWN':
          newHead = { x: head.x, y: head.y + 1 };
          break;
        case 'LEFT':
          newHead = { x: head.x - 1, y: head.y };
          break;
        case 'RIGHT':
          newHead = { x: head.x + 1, y: head.y };
          break;
      }

      if (
        newHead.x < 0 ||
        newHead.x >= GRID_SIZE ||
        newHead.y < 0 ||
        newHead.y >= GRID_SIZE ||
        prevSnake.some(segment => segment.x === newHead.x && segment.y === newHead.y)
      ) {
        setGameOver(true);
        setIsPlaying(false);
        toast({
          title: '💀 Game Over!',
          description: `Your score: ${score}`,
          variant: 'destructive'
        });
        return prevSnake;
      }

      const newSnake = [newHead, ...prevSnake];

      if (newHead.x === food.x && newHead.y === food.y) {
        setScore(prev => prev + 1);
        setFood(generateFood(newSnake));
        toast({
          title: '🎃 Yummy!',
          description: 'You ate the candy!',
        });
        return newSnake;
      }

      newSnake.pop();
      return newSnake;
    });
  }, [isPlaying, gameOver, nextDirection, food, score, generateFood, toast]);

  useEffect(() => {
    if (isPlaying && !gameOver && difficulty) {
      gameLoopRef.current = setInterval(moveSnake, difficultySettings[difficulty].speed);
      return () => {
        if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      };
    }
  }, [isPlaying, gameOver, difficulty, moveSnake]);

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (!isPlaying || gameOver) return;

      switch (e.key) {
        case 'ArrowUp':
          e.preventDefault();
          if (direction !== 'DOWN') setNextDirection('UP');
          break;
        case 'ArrowDown':
          e.preventDefault();
          if (direction !== 'UP') setNextDirection('DOWN');
          break;
        case 'ArrowLeft':
          e.preventDefault();
          if (direction !== 'RIGHT') setNextDirection('LEFT');
          break;
        case 'ArrowRight':
          e.preventDefault();
          if (direction !== 'LEFT') setNextDirection('RIGHT');
          break;
        case ' ':
          e.preventDefault();
          togglePause();
          break;
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [direction, isPlaying, gameOver]);

  const backToMenu = () => {
    setDifficulty(null);
    resetGame();
  };

  if (!difficulty) {
    return (
      <div className="min-h-screen halloween-bg-4 py-8 px-4">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Gamepad2 className="h-12 w-12 text-primary" />
              <h1 className="text-5xl xl:text-6xl font-bold gradient-text">
                Snake Game
              </h1>
            </div>
            <p className="text-xl text-muted-foreground">
              Choose your difficulty level! 🐍
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {(Object.keys(difficultySettings) as Difficulty[]).map((diff) => (
              <Card
                key={diff}
                className="halloween-shadow smooth-transition hover:scale-105 cursor-pointer bg-card/95 backdrop-blur-sm"
                onClick={() => startGame(diff)}
              >
                <CardHeader>
                  <CardTitle className="text-3xl text-center">
                    {difficultySettings[diff].name}
                  </CardTitle>
                  <CardDescription className="text-center text-lg">
                    Speed: {difficultySettings[diff].speed}ms
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button className="w-full" size="lg">
                    <Play className="mr-2 h-5 w-5" />
                    Start Game
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card className="mt-8 halloween-shadow bg-card/95 backdrop-blur-sm">
            <CardHeader>
              <CardTitle>How to Play</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p>🎮 Use arrow keys to control the snake</p>
              <p>🍬 Eat the candy to grow longer</p>
              <p>⚠️ Don't hit the walls or yourself!</p>
              <p>⏸️ Press SPACE to pause/resume</p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen halloween-bg-1 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <Card className="halloween-shadow bg-card/95 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between flex-wrap gap-4">
              <div>
                <CardTitle className="text-3xl">
                  Snake Game - {difficultySettings[difficulty].name}
                </CardTitle>
                <CardDescription className="text-lg mt-2">
                  Score: {score}
                </CardDescription>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" onClick={togglePause} disabled={gameOver}>
                  {isPlaying ? <Pause className="h-5 w-5" /> : <Play className="h-5 w-5" />}
                </Button>
                <Button variant="outline" onClick={resetGame}>
                  <RotateCcw className="h-5 w-5" />
                </Button>
                <Button variant="outline" onClick={backToMenu}>
                  Menu
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="flex justify-center">
              <div
                className="border-4 border-border rounded-lg relative bg-card"
                style={{
                  width: GRID_SIZE * CELL_SIZE,
                  height: GRID_SIZE * CELL_SIZE
                }}
              >
                {snake.map((segment, index) => (
                  <div
                    key={`snake-${index}`}
                    className={`absolute ${index === 0 ? 'bg-primary' : 'bg-primary/80'} rounded-sm`}
                    style={{
                      left: segment.x * CELL_SIZE,
                      top: segment.y * CELL_SIZE,
                      width: CELL_SIZE - 2,
                      height: CELL_SIZE - 2
                    }}
                  />
                ))}
                <div
                  className="absolute bg-destructive rounded-full"
                  style={{
                    left: food.x * CELL_SIZE,
                    top: food.y * CELL_SIZE,
                    width: CELL_SIZE - 2,
                    height: CELL_SIZE - 2
                  }}
                />
                {gameOver && (
                  <div className="absolute inset-0 bg-background/90 flex items-center justify-center">
                    <div className="text-center">
                      <Trophy className="h-16 w-16 text-primary mx-auto mb-4" />
                      <h2 className="text-3xl font-bold mb-2">Game Over!</h2>
                      <p className="text-xl mb-4">Final Score: {score}</p>
                      <Button onClick={resetGame} size="lg">
                        <RotateCcw className="mr-2 h-5 w-5" />
                        Play Again
                      </Button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6 text-center text-muted-foreground">
              <p>Use arrow keys to move • Press SPACE to pause</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Game;
