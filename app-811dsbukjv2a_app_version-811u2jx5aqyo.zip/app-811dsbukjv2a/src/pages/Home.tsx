import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Candy, Ghost, Skull, Sparkles, Moon, Star } from 'lucide-react';

interface VideoData {
  id: string;
  title: string;
  description: string;
  embedUrl: string;
  icon: string;
}

const halloweenVideos: VideoData[] = [
  {
    id: '1',
    title: 'The Friendly Ghost Story',
    description: 'Meet Casper and his friends in this heartwarming Halloween tale about friendship.',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    icon: '👻'
  },
  {
    id: '2',
    title: 'The Magical Pumpkin Patch',
    description: 'Join the adventure as kids discover a magical pumpkin patch with talking pumpkins!',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    icon: '🎃'
  },
  {
    id: '3',
    title: 'The Little Witch\'s First Halloween',
    description: 'Follow a young witch learning to fly her broomstick for the first time on Halloween night.',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    icon: '🧙'
  },
  {
    id: '4',
    title: 'The Haunted House Adventure',
    description: 'Brave kids explore a not-so-scary haunted house and make new monster friends!',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    icon: '🏚️'
  },
  {
    id: '5',
    title: 'The Vampire\'s Candy Quest',
    description: 'A friendly vampire goes trick-or-treating for the first time and learns about sharing.',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    icon: '🧛'
  },
  {
    id: '6',
    title: 'The Skeleton Dance Party',
    description: 'Skeletons come alive for a fun dance party! Learn the spooky skeleton dance moves.',
    embedUrl: 'https://www.youtube.com/embed/dQw4w9WgXcQ',
    icon: '💀'
  }
];

const backgrounds = [
  'halloween-bg-1',
  'halloween-bg-2',
  'halloween-bg-3',
  'halloween-bg-4'
];

const Home: React.FC = () => {
  const [currentBg, setCurrentBg] = useState(0);
  const [loadingVideos, setLoadingVideos] = useState<{ [key: string]: boolean }>({});
  const [floatingElements, setFloatingElements] = useState<Array<{ id: number; left: number; delay: number; duration: number }>>([]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentBg((prev) => (prev + 1) % backgrounds.length);
    }, 30 * 60 * 1000);

    const elements = Array.from({ length: 15 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 5,
      duration: 10 + Math.random() * 10
    }));
    setFloatingElements(elements);

    return () => clearInterval(interval);
  }, []);

  const handleVideoLoad = (id: string) => {
    setLoadingVideos((prev) => ({ ...prev, [id]: false }));
  };

  const handleVideoStart = (id: string) => {
    setLoadingVideos((prev) => ({ ...prev, [id]: true }));
  };

  return (
    <div className={`min-h-screen ${backgrounds[currentBg]} smooth-transition py-8 px-4 relative overflow-hidden`}>
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {floatingElements.map((element) => (
          element.id % 3 === 0 ? (
            <Ghost
              key={`ghost-${element.id}`}
              className="absolute text-primary/20 animate-float"
              style={{
                left: `${element.left}%`,
                top: '-50px',
                animationDelay: `${element.delay}s`,
                animationDuration: `${element.duration}s`,
                width: '40px',
                height: '40px'
              }}
            />
          ) : element.id % 3 === 1 ? (
            <Star
              key={`star-${element.id}`}
              className="absolute text-secondary/20 animate-float"
              style={{
                left: `${element.left}%`,
                top: '-50px',
                animationDelay: `${element.delay}s`,
                animationDuration: `${element.duration}s`,
                width: '35px',
                height: '35px'
              }}
            />
          ) : (
            <Moon
              key={`moon-${element.id}`}
              className="absolute text-accent/20 animate-float"
              style={{
                left: `${element.left}%`,
                top: '-50px',
                animationDelay: `${element.delay}s`,
                animationDuration: `${element.duration}s`,
                width: '30px',
                height: '30px'
              }}
            />
          )
        ))}
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-4 mb-4">
            <Ghost className="h-12 w-12 text-primary animate-bounce" />
            <h1 className="text-5xl xl:text-6xl font-bold gradient-text">
              Spooky Story Time! 👻
            </h1>
            <Skull className="h-12 w-12 text-secondary animate-bounce" />
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Watch fun and friendly Halloween stories perfect for kids! 🎃
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {halloweenVideos.map((video) => (
            <Card key={video.id} className="halloween-shadow smooth-transition hover:scale-105 bg-card/95 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-start gap-3">
                  <div className="text-4xl flex-shrink-0">{video.icon}</div>
                  <div>
                    <CardTitle className="text-xl">{video.title}</CardTitle>
                    <CardDescription className="text-sm mt-2">
                      {video.description}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative aspect-video rounded-lg overflow-hidden bg-muted">
                  {loadingVideos[video.id] !== false && (
                    <Skeleton className="absolute inset-0 bg-muted" />
                  )}
                  <iframe
                    src={video.embedUrl}
                    title={video.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="w-full h-full"
                    onLoad={() => handleVideoLoad(video.id)}
                    onLoadStart={() => handleVideoStart(video.id)}
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Card className="inline-block halloween-shadow bg-card/95 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center gap-3">
                <Sparkles className="h-6 w-6 text-primary" />
                <p className="text-lg font-medium">
                  Ready to test your math skills? Head to the Maths page! 🧮
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Home;
