import Home from './pages/Home';
import Maths from './pages/Maths';
import Game from './pages/Game';
import Points from './pages/Points';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Home',
    path: '/',
    element: <Home />,
    visible: true
  },
  {
    name: 'Maths',
    path: '/maths',
    element: <Maths />,
    visible: true
  },
  {
    name: 'Game',
    path: '/game',
    element: <Game />,
    visible: true
  },
  {
    name: 'Points',
    path: '/points',
    element: <Points />,
    visible: true
  }
];

export default routes;
